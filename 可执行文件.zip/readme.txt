将scalpel.zip解压缩双击scalpel.exe即可运行，注意不可随意移动scalpel.exe位置，可以移动整个目录
测试程序为scalpelTest.exe双击即可运行
运行环境均为64位 win10